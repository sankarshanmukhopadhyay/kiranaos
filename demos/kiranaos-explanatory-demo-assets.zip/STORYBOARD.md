# KiranaOS Explanatory Demo Storyboard

## Format

- Duration: about 70 seconds
- Resolution: 1280 x 720
- Style: captioned product walkthrough, no voiceover required
- Output: MP4 suitable for GitHub README, LinkedIn, or product page embedding

## Scenes

| Scene | Purpose | On-screen focus |
|---|---|---|
| 1 | Frame the problem | Kirana orders arrive as text, images, and voice notes |
| 2 | Show customer-side continuity | Customers keep using WhatsApp, no new app required |
| 3 | Explain ingestion | Provider webhook normalises messages into a common payload |
| 4 | Show parsing | Items, quantities, confidence, and review states are extracted |
| 5 | Show operator dashboard | Pending, packed, delivered, review, dormant, and udhaari signals |
| 6 | Show order operations | Status update, amount, credit flag, and customer confirmation |
| 7 | Show delivery workflow | Agent assignment, route order, and delivery lifecycle |
| 8 | Show payment reconciliation | UPI webhook reduces outstanding credit and creates ledger evidence |
| 9 | Show security controls | JWT auth, signed webhooks, store scope, SSRF checks, CORS controls |
| 10 | Close with architecture | WhatsApp-native operations with auditable, production-ready records |

## Message

KiranaOS is not asking local retail to change its operating habits. It turns the habits that already exist into structured, auditable workflow records: orders, ledger entries, delivery assignments, payments, and operator actions.

