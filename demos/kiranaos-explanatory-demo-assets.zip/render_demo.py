from __future__ import annotations

import math
import os
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
FRAMES = ROOT / "frames"
OUT = ROOT / "kiranaos-explanatory-demo.mp4"

W, H = 1280, 720
FPS = 12
BG = "#0f1720"
PANEL = "#152231"
PANEL_2 = "#192b3d"
LINE = "#29435c"
TEXT = "#f2f6f8"
MUTED = "#9fb3c5"
GREEN = "#41c68a"
GOLD = "#f2b84b"
BLUE = "#59a9ff"
RED = "#ff6b6b"


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


F = {
    "hero": font(54, True),
    "h1": font(36, True),
    "h2": font(25, True),
    "body": font(22),
    "small": font(17),
    "tiny": font(14),
    "mono": font(18),
}


def ease(x: float) -> float:
    return 0.5 - 0.5 * math.cos(math.pi * max(0, min(1, x)))


def wrap(draw: ImageDraw.ImageDraw, text: str, width: int, fnt: ImageFont.FreeTypeFont) -> list[str]:
    lines: list[str] = []
    for para in text.split("\n"):
        words = para.split()
        line = ""
        for word in words:
            test = f"{line} {word}".strip()
            if draw.textbbox((0, 0), test, font=fnt)[2] <= width:
                line = test
            else:
                if line:
                    lines.append(line)
                line = word
        if line:
            lines.append(line)
    return lines


def text(draw: ImageDraw.ImageDraw, xy: tuple[int, int], content: str, fnt, fill=TEXT, width: int | None = None, leading=8):
    x, y = xy
    if width is None:
        draw.text((x, y), content, font=fnt, fill=fill)
        return
    for line in wrap(draw, content, width, fnt):
        draw.text((x, y), line, font=fnt, fill=fill)
        y += fnt.size + leading


def rr(draw: ImageDraw.ImageDraw, box, fill, outline=None, radius=18, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def base() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img)
    for i in range(0, H, 6):
        shade = int(18 + i / H * 14)
        draw.line((0, i, W, i), fill=(shade, shade + 8, shade + 14))
    draw.rectangle((0, H - 72, W, H), fill="#0b1118")
    text(draw, (48, H - 52), "KiranaOS demo", F["small"], MUTED)
    return img, draw


def caption(draw, content: str):
    rr(draw, (340, 614, 1225, 682), "#0b1118", LINE, 14)
    text(draw, (365, 632), content, F["body"], TEXT, 830, 3)


def pill(draw, x, y, label, fill, fg="#071014"):
    w = draw.textbbox((0, 0), label, font=F["small"])[2] + 30
    rr(draw, (x, y, x + w, y + 34), fill, None, 17)
    text(draw, (x + 15, y + 8), label, F["small"], fg)
    return x + w + 10


def phone(draw, x, y, messages: list[tuple[str, str]], active: int = -1):
    rr(draw, (x, y, x + 315, y + 520), "#071014", "#2a445b", 28, 2)
    rr(draw, (x + 16, y + 18, x + 299, y + 502), "#eff6ef", None, 20)
    draw.rectangle((x + 16, y + 18, x + 299, y + 74), fill="#075e54")
    text(draw, (x + 34, y + 36), "WhatsApp orders", F["small"], "#ffffff")
    cy = y + 96
    for idx, (who, msg) in enumerate(messages):
        side = who == "customer"
        fill = "#dff8c6" if side else "#ffffff"
        bx = x + (52 if side else 28)
        by = cy
        bw = 225
        bh = 54 + 20 * max(0, len(msg) // 27)
        if idx == active:
            rr(draw, (bx - 5, by - 5, bx + bw + 5, by + bh + 5), "#f2b84b", None, 16)
        rr(draw, (bx, by, bx + bw, by + bh), fill, "#c8d8c8", 14)
        text(draw, (bx + 13, by + 11), msg, F["small"], "#1b2a2f", bw - 26, 2)
        cy += bh + 18


def dashboard(draw, x, y):
    rr(draw, (x, y, x + 695, y + 410), PANEL, LINE, 18)
    text(draw, (x + 28, y + 24), "Operator dashboard", F["h2"])
    labels = [("Pending", "18", GOLD), ("Packed", "7", BLUE), ("Review", "3", RED), ("Udhaari", "Rs 8,420", GREEN)]
    sx = x + 28
    for label, value, color in labels:
        rr(draw, (sx, y + 76, sx + 150, y + 146), "#0d1721", "#263d52", 12)
        text(draw, (sx + 16, y + 90), label, F["tiny"], MUTED)
        text(draw, (sx + 16, y + 112), value, F["h2"], color)
        sx += 166
    rows = [
        ("Sunita Sharma", "atta 5kg, dal 1kg, oil 1L", "pending"),
        ("Meera Patel", "rice 10kg, tel 5L", "packed"),
        ("Voice note", "needs review", "review"),
        ("Ayesha Begum", "udhaari balance Rs 500", "credit"),
    ]
    ty = y + 176
    for name, items, status in rows:
        rr(draw, (x + 28, ty, x + 665, ty + 48), PANEL_2, "#24394f", 9)
        text(draw, (x + 45, ty + 13), name, F["small"], TEXT)
        text(draw, (x + 210, ty + 13), items, F["small"], MUTED)
        color = {"pending": GOLD, "packed": BLUE, "review": RED, "credit": GREEN}[status]
        text(draw, (x + 555, ty + 13), status, F["small"], color)
        ty += 58


def mini_dashboard(draw, x, y):
    rr(draw, (x, y, x + 560, y + 390), PANEL, LINE, 18)
    text(draw, (x + 28, y + 24), "Operator dashboard", F["h2"])
    labels = [("Pending", "18", GOLD), ("Packed", "7", BLUE), ("Review", "3", RED)]
    sx = x + 28
    for label, value, color in labels:
        rr(draw, (sx, y + 76, sx + 148, y + 146), "#0d1721", "#263d52", 12)
        text(draw, (sx + 16, y + 90), label, F["tiny"], MUTED)
        text(draw, (sx + 16, y + 112), value, F["h2"], color)
        sx += 164
    rows = [
        ("Sunita Sharma", "atta 5kg, dal 1kg", "pending"),
        ("Meera Patel", "rice 10kg, tel 5L", "packed"),
        ("Voice note", "needs review", "review"),
        ("Ayesha Begum", "udhaari Rs 500", "credit"),
    ]
    ty = y + 176
    for name, items, status in rows:
        rr(draw, (x + 28, ty, x + 532, ty + 48), PANEL_2, "#24394f", 9)
        text(draw, (x + 45, ty + 13), name, F["small"], TEXT)
        text(draw, (x + 215, ty + 13), items, F["small"], MUTED)
        color = {"pending": GOLD, "packed": BLUE, "review": RED, "credit": GREEN}[status]
        text(draw, (x + 435, ty + 13), status, F["small"], color)
        ty += 58


def pipeline(draw, x, y, active: int):
    steps = [
        ("Webhook", "Twilio or Meta"),
        ("Normalize", "IngestMessageIn"),
        ("Extract", "OCR or voice"),
        ("Parse", "items + confidence"),
        ("Record", "order + audit"),
    ]
    cx = x
    for idx, (a, b) in enumerate(steps):
        fill = "#1e3449" if idx <= active else "#111b26"
        outline = GREEN if idx == active else LINE
        rr(draw, (cx, y, cx + 180, y + 92), fill, outline, 16, 2)
        text(draw, (cx + 18, y + 20), a, F["h2"], TEXT)
        text(draw, (cx + 18, y + 55), b, F["tiny"], MUTED)
        if idx < len(steps) - 1:
            draw.line((cx + 190, y + 46, cx + 230, y + 46), fill=GREEN if idx < active else LINE, width=4)
        cx += 235


def architecture(draw):
    boxes = [
        (80, 135, "Customer WhatsApp", "text / image / voice"),
        (380, 135, "Webhook adapter", "signed provider ingress"),
        (680, 135, "KiranaOS API", "orders, ledger, delivery"),
        (980, 135, "Operator dashboard", "daily fulfilment"),
        (380, 405, "Security controls", "JWT, store scope, SSRF checks"),
        (680, 405, "Evidence records", "messages, payments, audit trail"),
    ]
    for x, y, title, sub in boxes:
        rr(draw, (x, y, x + 220, y + 110), PANEL, GREEN if "Security" in title else LINE, 16, 2)
        text(draw, (x + 18, y + 24), title, F["small"], TEXT, 180)
        text(draw, (x + 18, y + 58), sub, F["tiny"], MUTED, 180)
    for a, b in [((300, 190), (380, 190)), ((600, 190), (680, 190)), ((900, 190), (980, 190)), ((790, 245), (790, 405)), ((600, 460), (680, 460))]:
        draw.line((*a, *b), fill=GREEN, width=4)


def scene(idx: int, p: float) -> Image.Image:
    img, draw = base()
    if idx == 0:
        text(draw, (70, 86), "KiranaOS", F["hero"])
        text(draw, (74, 158), "WhatsApp-native order ops for kirana stores", F["h1"], GREEN, 500)
        text(draw, (76, 278), "Customer messages become structured orders, credit records, delivery work, and payment evidence.", F["body"], MUTED, 490)
        x = 76
        for label, col in [("No customer app", GREEN), ("Voice + image + text", GOLD), ("Audit evidence", BLUE)]:
            x = pill(draw, x, 395, label, col)
        mini_dashboard(draw, 660, 120)
        caption(draw, "The demo shows how everyday WhatsApp traffic becomes an operational control plane for the store.")
    elif idx == 1:
        text(draw, (60, 70), "1. Customers keep their existing habit", F["h1"])
        phone(draw, 74, 120, [
            ("customer", "Sunita ji: atta 5kg, toor dal 1kg, oil 1L"),
            ("customer", "Photo: handwritten grocery list"),
            ("customer", "Voice note: rice, curd, tomatoes"),
            ("store", "Received. We will pack this now."),
        ], active=int(p * 3.9))
        rr(draw, (465, 160, 1165, 470), PANEL, LINE, 18)
        text(draw, (505, 205), "Design principle", F["h2"], GREEN)
        text(draw, (505, 252), "Do not force the buyer into a new app. Meet the order where it already arrives, then structure it for the store.", F["h1"], TEXT, 580, 10)
        caption(draw, "The customer experience stays familiar. The store gets structured work behind the scenes.")
    elif idx == 2:
        text(draw, (60, 70), "2. Inbound messages become a common payload", F["h1"])
        pipeline(draw, 78, 230, int(p * 4.9))
        text(draw, (94, 378), "Every provider-specific message is normalized before business logic runs.", F["body"], MUTED, 1040)
        caption(draw, "Twilio or Meta can sit at the edge, but the core system works with one stable ingestion contract.")
    elif idx == 3:
        text(draw, (60, 70), "3. Parsing produces reviewable order evidence", F["h1"])
        rr(draw, (78, 140, 540, 520), "#f6f0df", "#d6caa8", 18)
        text(draw, (115, 178), "Incoming text", F["h2"], "#2f2a1f")
        text(draw, (115, 232), "atta 5kg, toor dal 1kg,\nsarson ka tel 1L, namak", F["body"], "#2f2a1f", 360)
        rr(draw, (620, 140, 1165, 520), PANEL, LINE, 18)
        text(draw, (650, 178), "Parsed items", F["h2"], GREEN)
        rows = [("atta", "5", "kg", "0.85"), ("toor dal", "1", "kg", "0.85"), ("sarson ka tel", "1", "l", "0.85"), ("namak", "1", "pcs", "0.65")]
        y = 240
        for row in rows:
            rr(draw, (650, y, 1128, y + 44), PANEL_2, "#273f55", 8)
            for x, val in zip([670, 875, 955, 1035], row):
                text(draw, (x, y + 12), val, F["small"], TEXT if x < 1035 else GOLD)
            y += 58
        caption(draw, "The parser extracts items and confidence. Ambiguous inputs do not disappear; they move into review.")
    elif idx == 4:
        text(draw, (60, 70), "4. The operator sees work, risk, and cash", F["h1"])
        dashboard(draw, 80, 135)
        rr(draw, (820, 165, 1160, 485), PANEL, LINE, 18)
        text(draw, (850, 205), "Signals that matter", F["h2"], GREEN)
        bullets = ["Pending orders", "Low-confidence review", "Dormant customers", "Outstanding udhaari", "Delivered today"]
        by = 260
        for b in bullets:
            pill(draw, 850, by, b, "#263d52", TEXT)
            by += 44
        caption(draw, "The dashboard is not a vanity view. It prioritizes actions the store owner can take today.")
    elif idx == 5:
        text(draw, (60, 70), "5. Order actions create customer-facing proof", F["h1"])
        rr(draw, (80, 140, 610, 520), PANEL, LINE, 18)
        text(draw, (112, 178), "Order #1042", F["h2"], TEXT)
        for y, label, val, col in [(240, "Status", "packed", BLUE), (296, "Amount", "Rs 350", GOLD), (352, "Udhaari", "yes", GREEN)]:
            text(draw, (118, y), label, F["small"], MUTED)
            text(draw, (290, y), val, F["h2"], col)
        rr(draw, (116, 425, 570, 476), GREEN, None, 12)
        text(draw, (145, 439), "Record WhatsApp confirmation", F["body"], "#071014")
        phone(draw, 780, 120, [
            ("store", "Order #1042 packed. Amount Rs 350."),
            ("customer", "Please keep it on udhaari."),
            ("store", "Done. Balance updated."),
        ], active=0)
        caption(draw, "Status changes, confirmations, and credit decisions are recorded as operational evidence.")
    elif idx == 6:
        text(draw, (60, 70), "6. Delivery becomes assigned work, not memory", F["h1"])
        rr(draw, (78, 140, 1170, 515), PANEL, LINE, 18)
        text(draw, (115, 180), "Ramesh: delivery route", F["h2"], GREEN)
        stops = [("1", "Sunita Sharma", "Bldg A 302", "assigned"), ("2", "Meera Patel", "Bldg C 204", "picked_up"), ("3", "Ayesha Begum", "Bldg D 401", "assigned")]
        y = 250
        for no, name, addr, status in stops:
            rr(draw, (115, y, 1118, y + 58), PANEL_2, "#2d4860", 10)
            text(draw, (145, y + 16), no, F["h2"], GOLD)
            text(draw, (220, y + 18), name, F["body"], TEXT)
            text(draw, (520, y + 18), addr, F["body"], MUTED)
            text(draw, (870, y + 18), status, F["body"], BLUE if status == "picked_up" else GREEN)
            y += 78
        caption(draw, "Assignment and route order reduce ambiguity: who carries what, in which sequence, and in what state.")
    elif idx == 7:
        text(draw, (60, 70), "7. UPI payments reconcile the credit ledger", F["h1"])
        rr(draw, (90, 145, 500, 505), PANEL, LINE, 18)
        text(draw, (125, 190), "UPI webhook", F["h2"], GREEN)
        text(draw, (125, 248), "provider_ref: upi-001\namount: Rs 200\npayer_vpa: sunita@upi\ncustomer_id: 12", F["mono"], MUTED, 320, 10)
        rr(draw, (620, 145, 1160, 505), PANEL, LINE, 18)
        text(draw, (655, 190), "Ledger evidence", F["h2"], GREEN)
        text(draw, (655, 250), "Opening udhaari: +Rs 500\nUPI payment:     -Rs 200\nCurrent balance:  Rs 300", F["mono"], TEXT, 420, 12)
        caption(draw, "Payment events are not just marked paid. They become auditable ledger movements.")
    elif idx == 8:
        text(draw, (60, 70), "8. Security boundaries are part of the demo", F["h1"])
        cards = [
            ("JWT operators", "who can operate a store"),
            ("Store scope", "which tenant records are visible"),
            ("Signed webhooks", "which events are trusted"),
            ("Media URL checks", "which files may be fetched"),
            ("CORS controls", "which frontends may call APIs"),
            ("Audit records", "what evidence is produced"),
        ]
        for i, (a, b) in enumerate(cards):
            x = 90 + (i % 3) * 370
            y = 160 + (i // 3) * 155
            rr(draw, (x, y, x + 310, y + 110), PANEL, GREEN if i < 3 else LINE, 16, 2)
            text(draw, (x + 24, y + 24), a, F["h2"], TEXT)
            text(draw, (x + 24, y + 62), b, F["small"], MUTED, 255)
        caption(draw, "The system is designed around authority, scope, enforcement, and evidence, not only screens.")
    else:
        text(draw, (60, 70), "KiranaOS turns informal commerce into executable workflow", F["h1"], TEXT, 1080)
        architecture(draw)
        caption(draw, "WhatsApp remains the front door. KiranaOS becomes the store's auditable operating layer.")
    return img


def render():
    FRAMES.mkdir(exist_ok=True)
    for old in FRAMES.glob("frame_*.png"):
        old.unlink()
    durations = [5, 7, 7, 7, 7, 7, 7, 7, 7, 8]
    frame_no = 0
    for idx, seconds in enumerate(durations):
        total = seconds * FPS
        for n in range(total):
            p = ease(n / max(1, total - 1))
            img = scene(idx, p)
            img.save(FRAMES / f"frame_{frame_no:04d}.png", optimize=True)
            frame_no += 1

    cmd = [
        "ffmpeg",
        "-y",
        "-framerate",
        str(FPS),
        "-i",
        str(FRAMES / "frame_%04d.png"),
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        "-crf",
        "20",
        str(OUT),
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


if __name__ == "__main__":
    render()
    print(OUT)
